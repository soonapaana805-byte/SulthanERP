﻿using RestSharp;

namespace SulthanERP.Cashier.Services;

public class ApiService
{
    private readonly RestClient _client;

    public ApiService()
    {
        _client = new RestClient("http://localhost:5195/api/");
    }

    public async Task<RestResponse> GetAsync(string endpoint)
    {
        var request = new RestRequest(endpoint, Method.Get);

        return await _client.ExecuteAsync(request);
    }

    public async Task<RestResponse> PostAsync(string endpoint, object data)
    {
        var request = new RestRequest(endpoint, Method.Post);

        request.AddJsonBody(data);

        return await _client.ExecuteAsync(request);
    }
}